import re

# This class is used for extracting wire's name and number of bits in given line in the file.
# exp:
# wire [2:0] _001_;
# for this string it exract "_001_" and 2. Then save as struct. However number of bits is 2+1=3. it saves 3.

class WireInfo:
    def __init__(self, wire_string):
        self.name = None
        self.numBit = None
        self.process_string(wire_string)
    
    def process_string(self, wire_string):
        substrings = wire_string.split()
        
        # Check for valid number of substrings
        if len(substrings) < 3:
            # Single-bit wire
            self.name = substrings[1].replace(';', '')
            self.numBit = 1
        else:
            # Multiple-bit wire
            self.name = substrings[2].replace(';', '')  # Extract the name
            # Extract the bit number from the brackets
            numBit_str = re.search(r'\[(\d+):\d+\]', substrings[1])
            if numBit_str:
                self.numBit = int(numBit_str.group(1)) + 1
    
    def get_name(self):
        return self.name
    
    def get_numBit(self):
        return self.numBit
