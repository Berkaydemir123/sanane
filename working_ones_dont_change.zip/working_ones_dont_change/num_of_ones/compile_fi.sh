
PATH_ROOT= `pwd`
#rm -rf fi_work
mkdir -p fi_work
cd fi_work
verilator --top-module Stereo_Match -max-num-width 80000  --trace --trace-depth 1 -Wno-UNOPTFLAT --threads 4 -j 8 --unroll-count 3840 --cc /home/b.demir/newestrepository/stereo_vision_core-develop/FI/srcs/Stereo_Match.v /home/b.demir/newestrepository/stereo_vision_core-develop/FI/srcs/disp_cmp_13_64_7_sbtr.v /home/b.demir/newestrepository/stereo_vision_core-develop/FI/srcs/num_of_ones_7_with_sabouters.v /home/b.demir/newestrepository/stereo_vision_core-develop/FI/sbtr_cells/shift_register.v /home/b.demir/newestrepository/stereo_vision_core-develop/FI/sbtr_cells/basic_sabotuer.v /home/b.demir/newestrepository/stereo_vision_core-develop/FI/sbtr_cells/super_sabouter.v --exe /home/b.demir/newestrepository/stereo_vision_core-develop/FI/Stereo_Match_fi_tb.cpp
make -C obj_dir -f VStereo_Match.mk VStereo_Match 
