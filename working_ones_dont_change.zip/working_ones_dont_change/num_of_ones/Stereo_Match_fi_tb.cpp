#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <verilated.h>
#include <verilated_vcd_c.h>
#include "VStereo_Match.h"
#include "VStereo_Match___024root.h"

#define TRACE_EN

vluint64_t sim_time = 0;
vluint64_t index_data = 0;
vluint64_t fault_idx = 3;

int main(int argc, char** argv, char** env) {
    VStereo_Match *dut = new VStereo_Match;
    std::vector<int> image_left;
    std::vector<int> image_right;
    std::vector<int> image_valid;

    std::vector<int> fault_descriptor;
    std::vector<int> output_valid;
    std::vector<int> output_data;
    
    std::ifstream file_image_left("../input_vector_left_image.txt"); 
    std::ifstream file_image_right("../input_vector_right_image.txt"); 
    std::ifstream file_image_valid("../input_vector_valid.txt"); 
    std::ofstream outputDato("../output_vector_data.txt"); // create a new output file or overwrite an existing one
    std::ofstream outputValid("../output_vector_valid.txt");
    std::ifstream file_fault_descriptor("fault_descriptor.txt");

    std::string line;
    if(file_image_left)
    while(std::getline(file_image_left, line)){
        image_left.push_back(std::stoi(line));
    }
    while(std::getline(file_image_right, line)){
        image_right.push_back(std::stoi(line));
    }
    while(std::getline(file_image_valid, line)){
        image_valid.push_back(std::stoi(line));
    }
    while(std::getline(file_fault_descriptor, line)){
        fault_descriptor.push_back(std::stoi(line));
    }
    
    Verilated::traceEverOn(true);
    #ifdef TRACE_EN
        VerilatedVcdC *m_trace = new VerilatedVcdC;
        dut->trace(m_trace, 1);
        m_trace->open("waveform.vcd");
    #endif

    // Define bit positions
    constexpr uint8_t TFEn_BIT = 3;
    constexpr uint8_t CLK_BIT = 2;
    constexpr uint8_t RST_BIT = 1;
    constexpr uint8_t EN_BIT = 0;

    // Initialize signals
    dut->i_Tresh_LRCC = 8;
    dut->injector_i_FI_CONTROL_PORT = 0; // Reset all control signals

    for (int i = 0; i < 51; i++) {
        dut->i_clk ^= 1; // Toggle clock
        dut->injector_i_FI_CONTROL_PORT ^= (1 << CLK_BIT); // Toggle CLK bit
        dut->eval();
        #ifdef TRACE_EN
            m_trace->dump(sim_time);
        #endif
        sim_time++;
    }

    
    dut->i_rst = 1;
    dut->injector_i_FI_CONTROL_PORT |= (1 << RST_BIT); // Set RST bit to 1
    
    

    // Saboteur configuration
    int modules=fault_descriptor[0];
    int component=fault_descriptor[1];
    int sr_leght=fault_descriptor[2];

    for (int m_shift = 0; m_shift < modules; m_shift++) {
        for (int bit_shift = 0; bit_shift < sr_leght; bit_shift++) {
            dut->injector_i_FI_CONTROL_PORT |= (1 << EN_BIT); // Enable saboteur
            dut->i_clk ^= 1; // Toggle clock
            dut->injector_i_FI_CONTROL_PORT ^= (1 << CLK_BIT); // Toggle CLK bit
            if (m_shift == component) {
             //   dut->injector_i_SI = fault_descriptor[bit_shift + 3];
             dut->injector_i_SI = 0;
            } else {
                dut->injector_i_SI = 0;
            }
            dut->eval();
            #ifdef TRACE_EN
                m_trace->dump(sim_time);
            #endif
            sim_time++;
            dut->i_clk ^= 1;
            dut->injector_i_FI_CONTROL_PORT ^= (1 << CLK_BIT); // Toggle CLK bit
            dut->eval(); 
            #ifdef TRACE_EN 
                m_trace->dump(sim_time);
            #endif
            sim_time++; 
        }
    }

    dut->injector_i_SI = 0;
    dut->injector_i_FI_CONTROL_PORT &= ~(1 << EN_BIT); // Disable saboteur
    dut->injector_i_FI_CONTROL_PORT |= (1 << TFEn_BIT); // Enable fault injector

    // Workload execution
    if (outputDato.is_open() && outputValid.is_open()) {
    
        while (index_data < image_valid.size()) {
            dut->i_clk ^= 1; // Toggle clock
  //          dut->injector_i_FI_CONTROL_PORT &= ~(1 << CLK_BIT); // Toggle CLK bit
            dut->eval();
            #ifdef TRACE_EN
                m_trace->dump(sim_time);
            #endif

            if (dut->i_clk == 0) {
                dut->i_dval = image_valid[index_data];
                dut->i_dato_L = image_left[index_data];
                dut->i_dato_R = image_right[index_data];
                outputDato << int(dut->o_dato) << "\n";
                outputValid << int(dut->o_dval) << "\n";
                index_data++;
            }
            sim_time++;
        }
        outputDato.close();
        outputValid.close();
        #ifdef TRACE_EN
            m_trace->close();
        #endif
        delete dut;
    } else {
        std::cerr << "Error opening file\n";
    }

    exit(EXIT_SUCCESS);
}

