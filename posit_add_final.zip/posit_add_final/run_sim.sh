

verilator --timing --binary --trace --trace-depth 1 -Wno-lint -Wno-ASSIGNIN -Wno-PINMISSING --timescale-override 1ns/1ps -max-num-width 80000 \
basic_sabotuer.v \
Module_0_gate_sbtr.v \
Module_1_gate_sbtr.v \
Module_2_gate_sbtr.v \
posit_add_fi_sbtr.v \
shift_register.v \
super_sabouter.v \
tb_posit_add_fault.v \
-Wno-moddup -Wno-fatal \
--top-module tb_posit_add_fault -o Vtb_posit_add_fault

./obj_dir/Vtb_posit_add_fault
