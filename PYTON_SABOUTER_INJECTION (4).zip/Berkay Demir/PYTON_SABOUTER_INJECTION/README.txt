To inject sabouters:
	1- Add the design in the folder
	2- Modify sabouter_injection.py with your file name.
	3- Run "sabouters_injection.py"

The files start with "f_" are functions.
There are also a class which store signals defined as wire.
More information available in the codes as comments.