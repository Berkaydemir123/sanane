from class_wire_extraction import WireInfo
from f_define_new_wire import define_new_wire
from f_find_wire_name import find_wire_name
from f_insert_sabouter import insert_instances
import shutil
import math

# This program extract signals defined as wire in the synthesized verilog design and then create new wires for these signals.
# The new created wires are named with prefix "temp_". also bit numbers  are preserved.
# ie.  
# wire [2:0] _01_; -> new created wire: wire [2:0] temp__01_;
#
# after that, signal names which are assigned in the design are replaced with that "temp_.." signal.
# ie.
# assign _07_ = _05_ | _06_; -> assign temp__07_ = _05_ | _06_;
#
# and then for all new wires, super sabouters are inserted before "endmodule" for these new wires.
# ie.
# super_sabouter #(.WIDTH(1)) SS9(
#                 .i_bit(temp__09_),
#                  .i_en(EN),
#                  .i_ctrl(CTRL),
#                   .o_fault(_09_)
#                   );
#
# lastly the signals "EN" and "CTRL" are defined as input in the verilog file


def main():
    wire_list = []          # holds wire names and their bit number
    temp_wire_list = []     # holds new temporary wire names and their number of bits
    number_of_super_sabouter = 0
    input_list = []         # list for input signals
    list_txt_assign_input = []  # text that assign input signal to temporary input signal

# WRITE YOUR FILENAMES HERE (MODIFY ACCORDING TO YOUR DESIGN):
    filename = "design.v"                   # the netlist
    new_filename = "modified_design.v"      # output: new netlist

# read line by line and save wire names with their number of bits into the list:
    with open(filename, 'r') as file:
        for line_design in file:
            if 'wire' in line_design:        
                wire_info = WireInfo(line_design.strip())             # send to class and get wire name and number of bits
                new_wire_info = define_new_wire(wire_info)     # send previous information to the function that create new temp wire    
                wire_list.append(wire_info)             # append the list
                temp_wire_list.append(new_wire_info)
            elif 'input' in line_design:
                input_info = WireInfo(line_design.strip())
                input_list.append(input_info)

    file.close()

    for x in input_list:
        for y in wire_list:
            if x.get_name() == y.get_name():
                wire_list.remove(y)
 
    total_enables = 0
    index = 0
    for x in wire_list:
        print(f"Name: {x.get_name()} - Number of Bits: {x.get_numBit()}")
        print(f"New Definition: {temp_wire_list[index]}")
        total_enables = total_enables + x.get_numBit()
        index = index + 1
        number_of_super_sabouter = number_of_super_sabouter + 1

    # copy the original file:
    shutil.copy(filename,new_filename)

    
    with open(new_filename, 'r') as file:
        lines = file.readlines()    #  returns the contents of the entire file 

    # insert new wires and replace wire names after "assign"
    with open(new_filename, 'w') as file:
        for line in lines:
                                                                       # insert my new temporary wires
            if 'module' in line and 'endmodule' not in line:           # Check if the current line contains 'module'
                file.write(line)
                file.writelines(temp_wire_list)                        # Insert new lines after the line containing 'module'
            elif 'assign' in line:                                     
                wire_name_assign = find_wire_name(line)
                replace_wire_with = "temp_" + wire_name_assign         # exp: replace "_000_" with "temp__000_"
                new_line = line.replace(wire_name_assign, replace_wire_with)  
                file.write(new_line)          
            else:
                file.write(line)
    file.close()
    # insert components before "endmodule":

    # find line number for "endmodule"
    with open(new_filename, 'r') as file:
        lines = file.readlines()    #  returns the contents of the entire file 

    endmodule_line_number = None
    for i, line in enumerate(lines):
        if 'endmodule' in line:
            endmodule_line_number = i   # find line number containing "endmodule". with that i will insert components before endmodule
            break
    
    numBit_SS = math.floor(math.log2(number_of_super_sabouter)) + 1
    WIDTH = total_enables + 2
    COMPONENTS1 = insert_instances(wire_list, "i_TFEn", "EN_CTRL", WIDTH)

    new_lines = lines[:endmodule_line_number]  + COMPONENTS1 + lines[endmodule_line_number:]

    with open(new_filename, 'w') as file:
        file.writelines(new_lines)
    file.close()

    # insert new ports for inputs and outputs
    new_ports       = ", i_CLK_x, i_RST_x, i_TFEn, i_EN_SR, i_SI, o_CLK_x, o_RST_x, o_TFEn, o_EN_SR, o_SI"
    parameter       = f" #(parameter WIDTH_SR = {WIDTH})"
    def_si          =  "  input i_SI;\n"
    def_en_sr       =  "  input i_EN_SR;\n"
    def_TFEn        =  "  input i_TFEn;\n"
    def_CLK_x       =  "  input i_CLK_x;\n"
    def_RST_x       =  "  input i_RST_x;\n"
    def_o_si        =  "  output o_SI;\n"
    def_o_en_sr     =  "  output o_EN_SR;\n"
    def_o_TFEn      =  "  output o_TFEn;\n"
    def_o_CLK_x     =  "  output o_CLK_x;\n"
    def_o_RST_x     =  "  output o_RST_x;\n"
    def_wire        = f"  wire [WIDTH_SR-1:0] o_SR;\n"
    assign_o_CLK_x  =  "  assign o_CLK_x = i_CLK_x;\n"
    assign_o_RST_x  =  "  assign o_RST_x = i_RST_x;\n"
    assign_O_TFEn   =  "  assign o_TFEn = i_TFEn;\n"
    assign_o_EN_SR  =  "  assign o_EN_SR = i_EN_SR;\n"
    assign_o_SI     =  "  assign o_SI = o_SR[0];\n"


    with open(new_filename, 'r') as file:
        lines = file.readlines()
    with open(new_filename, 'w') as file:
        for line in lines:
            if 'module' in line and 'endmodule' not in line:
                x = line.find("(")
                str1 = line[:x] + parameter + line[x:]
                y = str1.find(";")
                new_line = str1[:y-1] + new_ports + str1[y-1:]

                file.write(new_line)
                file.write(def_si)
                file.write(def_en_sr)
                file.write(def_TFEn)
                file.write(def_CLK_x)
                file.write(def_RST_x)

                file.write(def_o_si)
                file.write(def_o_en_sr)
                file.write(def_o_TFEn)
                file.write(def_o_CLK_x)
                file.write(def_o_RST_x)

                file.write(def_wire)

                file.write(assign_o_CLK_x)
                file.write(assign_o_RST_x)
                file.write(assign_O_TFEn)
                file.write(assign_o_EN_SR)
                file.write(assign_o_SI)
            else:
                file.write(line)
    file.close()

    total = total_enables + 2
    print("Total number of bits for shift register:")
    print(f"[Enable Signals ({total_enables})] + [Control (2)] = {total}")

    print("Super Sabouters' lengths respectively (0 to N):")
    for x in wire_list:      
        print(x.get_numBit(), end=' ')

    print("\nNumber of Super Sabouter:", number_of_super_sabouter)
    print("Number of bits to represent Super Sabouter Number:", numBit_SS)
    

if __name__ == "__main__":
    main()
