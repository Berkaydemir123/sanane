from class_wire_extraction import WireInfo

# This function define new temporary wires.
# exp:
# wire [11:0] _004_;
# new wire definition:
# wire [11:0] temp__004_;

def define_new_wire(original_wire):
    new_name = "temp_" + original_wire.get_name()
    numBits =  original_wire.get_numBit() - 1

    if original_wire.get_numBit() > 1:
        definition = "  wire [" + str(numBits) + ":0] " + new_name + ";\n"
    else:
        definition = "  wire " + new_name + ";\n"

    
    # print("new def:", definition ,numBits)

    return definition